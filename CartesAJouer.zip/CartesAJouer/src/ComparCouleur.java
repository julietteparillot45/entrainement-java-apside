
import java.util.Comparator;

public class ComparCouleur implements Comparator<Carte> {

    @Override
    public int compare(Carte o1, Carte o2) {
        return o1.getCouleurNum()-o2.getCouleurNum();
    }

}
