
import java.util.Comparator;

public class ComparValeur implements Comparator<Carte> {

    @Override
    public int compare(Carte o1, Carte o2) {
        return o1.getValeurInt()-o2.getValeurInt();
    }
}
