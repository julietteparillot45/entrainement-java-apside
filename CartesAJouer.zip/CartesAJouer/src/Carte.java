public class Carte {
    private int valeur;
    private String couleur;

    public Carte(int valeur, String couleur) {
        this.valeur=valeur;
        this.couleur=couleur;
    }

    public int getValeurInt() {
        return this.valeur;
    }

    public String getCouleur() {
        return this.couleur;
    }

    public String getValeur() {
        switch (this.valeur){
            case 1 : return "As";
            case 2 : return "Deux";
            case 3 : return "Trois";
            case 4 : return "Quatre";
            case 5 : return "Cinq";
            case 6 : return "Six";
            case 7 : return "Sept";
            case 8 : return "Huit";
            case 9 : return "Neuf";
            case 10 : return "Dix";
            case 11 : return "Valet";
            case 12 : return "Dame";
            case 13 : return "Roi";
            default : return "Inconnu";
        }
    }

    public int getCouleurNum() {
        switch (couleur){
            case "trefle" : return 0;
            case "carreau" : return 1;
            case "coeur" : return 2;
            case "pique" : return 3;
            default : return -1;
        }
    }

}
