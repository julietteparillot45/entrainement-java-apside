
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {

    private List<Carte> main;
    private Carte selec;

    public Main(){
        this.main = new ArrayList<>();
        selec=null;
    }

    public void triParValeurs() {
        Collections.sort(main, new ComparValeur());
    }

    public void triParCouleurs() {
        Collections.sort(main, new ComparCouleur());
    }

    public void jouer() {
    }

    public void piocher() {
    }

    public void jouerToutesValeurs() {
    }

    public void jouerToutesCouleurs() {
    }

    public void setCarteSelectionee(Carte carte) {
        selec=carte;
    }

    public void add(Carte carte) {
        this.main.add(carte);
    }

    public List<Carte> getMesCartes() {
        return this.main;
    }

    public Carte getCarteSelectionnee() {
        return selec;
    }

}
